# Lavish Style — Saree Website

এই ফোল্ডারে একটি responsive বাংলা শাড়ির ব্যবসার ওয়েবসাইট আছে।

## ফাইল
- index.html — মূল ওয়েবসাইট
- style.css — ডিজাইন ও responsive layout
- script.js — menu, product filter ও WhatsApp order

## গুরুত্বপূর্ণ
1. index.html-এর sample product name/price নিজের আসল পণ্য অনুযায়ী বদলান।
2. product-image অংশে চাইলে নিজের শাড়ির ছবি বসাতে পারবেন।
3. WhatsApp নম্বর ও email প্রয়োজন অনুযায়ী বদলান।
4. GitHub Pages-এ প্রকাশ করতে তিনটি ফাইল একই repository-র root-এ রাখুন এবং Settings → Pages থেকে Deploy from branch নির্বাচন করুন।
